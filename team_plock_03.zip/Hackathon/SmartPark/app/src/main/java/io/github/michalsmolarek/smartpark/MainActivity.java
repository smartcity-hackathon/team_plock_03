package io.github.michalsmolarek.smartpark;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity implements OnMapReadyCallback {

    @Override
    public void onMapReady(GoogleMap googleMap) {
        Log.d(TAG, "onMapReady: Mapa jest gotowa");
        mMap = googleMap;

        if (mLocationPermissionsGranted) {
            getDeviceLocation();

            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this,
                    Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            mMap.setMyLocationEnabled(true);
            mMap.getUiSettings().setMyLocationButtonEnabled(false);

            LatLng naszParking = new LatLng(52.550307, 19.672222);
            MarkerOptions markerOptions = new MarkerOptions();
            markerOptions.position(naszParking)
                    .title("16 WOLNYCH MIEJSC")
                    .icon(BitmapDescriptorFactory.fromResource(R.drawable.green));

            InfoWindowData info = new InfoWindowData();
            info.setText("16 WOLNYCH MIEJSC");

            CustomMarkerWindow customMarkerWindow = new CustomMarkerWindow(this);
            mMap.setInfoWindowAdapter(customMarkerWindow);

            Marker marker = mMap.addMarker(markerOptions);
            marker.showInfoWindow();


            LatLng inneKoordynaty = new LatLng(52.553607, 19.674122);
            MarkerOptions markerOptions2 = new MarkerOptions();
            markerOptions2.position(inneKoordynaty)
                    .title("4 WOLNYCH MIEJSC")
                    .icon(BitmapDescriptorFactory.fromResource(R.drawable.red));

            InfoWindowData info2 = new InfoWindowData();
            info2.setText("4 WOLNYCH MIEJSC");

            CustomMarkerWindow customMarkerWindow2 = new CustomMarkerWindow(this);
            mMap.setInfoWindowAdapter(customMarkerWindow2);

            Marker marker2 = mMap.addMarker(markerOptions2);
            marker2.showInfoWindow();


            LatLng inneKoordynaty3 = new LatLng(52.551607, 19.674522);
            MarkerOptions markerOptions3 = new MarkerOptions();
            markerOptions3.position(inneKoordynaty3)
                    .title("6 WOLNYCH MIEJSC")
                    .icon(BitmapDescriptorFactory.fromResource(R.drawable.yellow));

            InfoWindowData info3 = new InfoWindowData();
            info3.setText("6 WOLNYCH MIEJSC");

            CustomMarkerWindow customMarkerWindow3 = new CustomMarkerWindow(this);
            mMap.setInfoWindowAdapter(customMarkerWindow3);

            Marker marker3 = mMap.addMarker(markerOptions3);
            marker3.showInfoWindow();


            LatLng inneKoordynaty4 = new LatLng(52.551507, 19.667922);
            MarkerOptions markerOptions4 = new MarkerOptions();
            markerOptions4.position(inneKoordynaty4)
                    .title("7 WOLNYCH MIEJSC")
                    .icon(BitmapDescriptorFactory.fromResource(R.drawable.yellow2));

            InfoWindowData info4 = new InfoWindowData();
            info4.setText("7 WOLNYCH MIEJSC");

            CustomMarkerWindow customMarkerWindow4 = new CustomMarkerWindow(this);
            mMap.setInfoWindowAdapter(customMarkerWindow4);

            Marker marker4 = mMap.addMarker(markerOptions4);
            marker4.showInfoWindow();


            databaseReference = FirebaseDatabase.getInstance().getReference();
            final Marker[] array = new Marker[2];

            databaseReference.child("miejsce").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        String x = dataSnapshot.child("x").getValue().toString();
                        String y = dataSnapshot.child("y").getValue().toString();
                        String msg = dataSnapshot.child("msg").getValue().toString();

                        double xx = Double.parseDouble(x);
                        double yy = Double.parseDouble(y);

                    if(array[0] == null){
                        array[0] = mMap.addMarker(new MarkerOptions().position(new LatLng(xx, yy)).title(msg + " wolnych miejsc"));
                        array[0].showInfoWindow();
                        array[0].setIcon(BitmapDescriptorFactory.fromResource(R.drawable.green_bubble));
                        if(array[1] != null) {
                            array[1].remove();
                            array[1] = null;
                        }
                    }
                    else if(array[1] == null){
                        array[1] = mMap.addMarker(new MarkerOptions().position(new LatLng(xx, yy)).title(msg + " wolnych miejsc"));
                        array[1].showInfoWindow();
                        array[1].setIcon(BitmapDescriptorFactory.fromResource(R.drawable.green_bubble));
                        if(array[1] != null){
                            array[0].remove();
                            array[0] = null;
                        }
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });


//            databaseReference.child("miejsce").addValueEventListener(new ValueEventListener() {
//                @Override
//                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
//
//                        String x = dataSnapshot.child("x").getValue().toString();
//                        String y = dataSnapshot.child("y").getValue().toString();
//                        String msg = dataSnapshot.child("msg").getValue().toString();
//
//                        double xx = Double.parseDouble(x);
//                        double yy = Double.parseDouble(y);
//
//                    m = mMap.addMarker(new MarkerOptions().position(new LatLng(xx, yy)).title(msg));
//
//                    Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();
//
//                }
//
//                @Override
//                public void onCancelled(@NonNull DatabaseError databaseError) {
//
//                }
//            });


//            databaseReference.addChildEventListener(new ChildEventListener() {
//                @Override
//                public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
//                    for(DataSnapshot ds: dataSnapshot.getChildren()){
//                        // ID OSIEDLA
//                        mapLevel_1.put(ds.getKey(), ds.getValue().toString());
//                        for( DataSnapshot ds2 : ds.getChildren() ){
//                            // PARKINGI
//                            mapLevel_2.put(ds2.getKey(), ds2.getValue().toString());
//                            for(DataSnapshot ds3 : ds2.getChildren()){
//                                // ID PARKINGÓW
//                                for(DataSnapshot ds4 : ds3.getChildren()){
//
//                                    String iks = ds4.child("G_szer").getValue().toString();
//                                    String igr = ds4.child("G_wys").getValue().toString();
//                                    String czyZaj = ds4.child("czy_zajete").getValue().toString();
//
//                                    double iks1 = Double.parseDouble(iks);
//                                    double igr1 = Double.parseDouble(igr);
//
//                                    ArrayList<Marker> markerArrayList = new ArrayList<>();
//
//                                    for(int i = 0; i < ds4.getChildrenCount(); i++){
//                                        markerArrayList.add(mMap.addMarker(new MarkerOptions().position(new LatLng(iks1, igr1)).title(czyZaj)));
//                                    }
//
//                                    String msg = markerArrayList.get(2).getTitle();
//
//                                    Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();
//
//                                    m = mMap.addMarker(new MarkerOptions()
//                                            .position(new LatLng(iks1, igr1)).title(czyZaj)
//                                    );
//
//                                    for(DataSnapshot ds5 : ds4.getChildren()){
//                                        // MIEJSCA
//                                        mapLevel_4.put(ds5.getKey(), ds5.getValue().toString());
//                                    }
//                                }
//                            }
//                        }
//                    }
//                }
//
//                @Override
//                public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
//                }
//
//                @Override
//                public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {
//
//                }
//
//                @Override
//                public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
//
//                }
//
//                @Override
//                public void onCancelled(@NonNull DatabaseError databaseError) {
//
//                }
//            });


//            mMap.setOnCameraMoveListener(new GoogleMap.OnCameraMoveListener() {
//                @Override
//                public void onCameraMove() {
//                    float zoom = mMap.getCameraPosition().zoom;
//                    Log.d(TAG, Float.toString(zoom));
//
//                    List<Marker> listMarkers = new ArrayList<>();
//
//                    if( zoom > STREFA_REJONY ) {
//                        mapLevel_1.entrySet().forEach(mapMarker -> {
//                            listMarkers.add(new MarkerOptions()
//                            .position(new LatLng(mapMarker.getValue().)));
//                        });
//                    }
//
//                }
//            });

        }
    }

    DatabaseReference databaseReference;

    DatabaseReference tmp = FirebaseDatabase.getInstance().getReference("id_osiedla/parkingi/id_parkingu1/miejsca/id_miejsca1");

    private static final String TAG = "MainActivity";

    private static final String FINE_LOCATION = Manifest.permission.ACCESS_FINE_LOCATION;
    private static final String COURSE_LOCATION = Manifest.permission.ACCESS_COARSE_LOCATION;
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1234;
    private static final float DEFAULT_ZOOM = 15f;

    // zoom vars
    private final double STREFA_REJONY = 16.2;
    private final double STREFA_ULICE = 17.0;
    private final double STREFA_MIEJSCA = 18.0;

    private static Marker m;

    //vars
    private Boolean mLocationPermissionsGranted = false;
    private GoogleMap mMap;
    private FusedLocationProviderClient mFusedLocationProviderClient;

    FloatingActionButton fab;

    Map<String, String> mapLevel_1 = new HashMap<>();
    Map<String, String> mapLevel_2 = new HashMap<>();
    Map<String, String> mapLevel_3 = new HashMap<>();
    Map<String, String> mapLevel_4 = new HashMap<>();


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getLocationPermission();

        fab = findViewById(R.id.floatingActionButton);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getDeviceLocation();
            }
        });

    }

    private void getDeviceLocation(){
        Log.d(TAG, "getDeviceLocation: lokalizowanie");

        mFusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);

        try{
            if(mLocationPermissionsGranted){

                final Task location = mFusedLocationProviderClient.getLastLocation();
                location.addOnCompleteListener(new OnCompleteListener() {
                    @Override
                    public void onComplete(@NonNull Task task) {
                        if(task.isSuccessful()){
                            Log.d(TAG, "onComplete: znaleziono lokalizacje");
                            Location currentLocation = (Location) task.getResult();

                            moveCamera(new LatLng(currentLocation.getLatitude(), currentLocation.getLongitude()),
                                    DEFAULT_ZOOM);

                        }else{
                            Log.d(TAG, "onComplete: lokalizacja jest nullem");
                            Toast.makeText(MainActivity.this, "nie mozna pobrac lokalizacji", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        }catch (SecurityException e){
            Log.e(TAG, "getDeviceLocation: błąd bezpieczeństwa: " + e.getMessage() );
        }
    }

    private void moveCamera(LatLng latLng, float zoom){
        Log.d(TAG, "moveCamera: Przenoszenie kamery do:: " + latLng.latitude + ", " + latLng.longitude );
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, zoom));
    }

    private void initMap(){
        Log.d(TAG, "initMap: Inicjalizowanie mapy");
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);

        mapFragment.getMapAsync(MainActivity.this);
    }

    private void getLocationPermission(){
        Log.d(TAG, "getLocationPermission: autoryzacja");
        String[] permissions = {Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION};

        if(ContextCompat.checkSelfPermission(this.getApplicationContext(),
                FINE_LOCATION) == PackageManager.PERMISSION_GRANTED){
            if(ContextCompat.checkSelfPermission(this.getApplicationContext(),
                    COURSE_LOCATION) == PackageManager.PERMISSION_GRANTED){
                mLocationPermissionsGranted = true;
                initMap();
            }else{
                ActivityCompat.requestPermissions(this,
                        permissions,
                        LOCATION_PERMISSION_REQUEST_CODE);
            }
        }else{
            ActivityCompat.requestPermissions(this,
                    permissions,
                    LOCATION_PERMISSION_REQUEST_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        mLocationPermissionsGranted = false;

        switch(requestCode){
            case LOCATION_PERMISSION_REQUEST_CODE:{
                if(grantResults.length > 0){
                    for(int i = 0; i < grantResults.length; i++){
                        if(grantResults[i] != PackageManager.PERMISSION_GRANTED){
                            mLocationPermissionsGranted = false;
                            Log.d(TAG, "onRequestPermissionsResult: odmówiono");
                            return;
                        }
                    }
                    Log.d(TAG, "onRequestPermissionsResult: przyznano");
                    mLocationPermissionsGranted = true;
                    //initialize our map
                    initMap();
                }
            }
        }
    }
}

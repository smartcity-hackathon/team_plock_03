package io.github.michalsmolarek.smartpark;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.widget.TextView;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.Marker;

public class CustomMarkerWindow implements GoogleMap.InfoWindowAdapter {

    Context context;

    public CustomMarkerWindow(Context c){
        context = c;
    }

    @Override
    public View getInfoWindow(Marker marker) {
        return null;
    }

    @Override
    public View getInfoContents(Marker marker) {

        View view = ((Activity) context).getLayoutInflater().inflate(R.layout.custom_bubble,null);

        TextView text = view.findViewById(R.id.customBubbleTextView);

        text.setText(marker.getTitle());

        return view;
    }
}
